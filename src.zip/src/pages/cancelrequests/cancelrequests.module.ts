import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CancelrequestsPage } from './cancelrequests';

@NgModule({
  declarations: [
    CancelrequestsPage,
  ],
  imports: [
    IonicPageModule.forChild(CancelrequestsPage),
  ],
})
export class CancelrequestsPageModule {}
