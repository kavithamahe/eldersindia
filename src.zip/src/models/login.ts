export interface Login {
  email: string;
  user_type: string;
  name: string;
  user_id: number;
  password:string;
  token:string;
  title:string;
}
